import { Navigate, createBrowserRouter } from "react-router-dom";
import App from "../App";

import CustomerInfo from "../Page/CustomerInfo";
import ProductPage from "../Page/ProductPage";
import AddForm from "../Page/AddForm";
import EditForm from "../Page/EditForm";
import NotFound from "../Page/NotFound";

const router = createBrowserRouter([
  {
    element: <App />,
    path: "/",

    children: [
      {
        element: <CustomerInfo />,
        path: "/",
      },
      {
        element: <CustomerInfo />,
        path: "/customer/:id",
      },
      {
        element: <ProductPage />,
        path: "/products/:id",
      },
      {
        element: <AddForm />,
        path: "/add/:id",
      },
      {
        element: <EditForm />,
        path: "/Edit/:id",
      },
      { path: "/NotFound", element: <NotFound /> },
      {
        path: "*",
        element: <Navigate to="/NotFound" />,
      },
    ],
  },
]);

export default router;
