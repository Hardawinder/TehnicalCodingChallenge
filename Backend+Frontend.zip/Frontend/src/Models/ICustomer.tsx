interface iCustomer{

    id:number,
    name:string,
    dateOfBirth:Date
    ,dateJoined?:Date
}

export default iCustomer;