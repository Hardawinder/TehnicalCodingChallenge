interface iPostProduct{

    productName:string,
    productPrice:number,
    customerId:number,
   
}

export default iPostProduct;