interface iProduct{

    productName:string,
    productPrice:number,
    customerId:number,
    id:number
}

export default iProduct;