import { TextField, Button, Container } from "@mui/material";
import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import iPostProduct from "../Models/IPostProduct";
import agent from "../Axios/agent";

export default function AddForm(){
     
    const[productName,setProductName]=useState<string>("");
    const[productPrice,setProductPrice]=useState<number>(0);
    const navigation=useNavigate();
    const{id}=useParams();
    const [productObj,setProductObj]=useState<iPostProduct>();


    useEffect(() => {
        if (productName !== "" && productPrice > 0 && id != null) {
            setProductObj({
                productName: productName,
                productPrice: productPrice,
                customerId: parseInt(id),
            });
        }
    }, [productName, productPrice, id]);


    function onNameChangeHandler(e:any){
        if(e.target.value!=""){
            setProductName(e.target.value)
        }
    }
    function onPriceChangeHandler(e:any){
        if(e.target.value>0){
            setProductPrice(e.target.value)
        }
    }

    function onSubmit(e:any){
        e.preventDefault();
      

        id!=null&&productObj!=null&&agent.Products.add(parseInt(id),productObj)
        .then(data=>console.log(data))
        .catch(error=>console.log(error))
        ;

        navigation(`/products/${id}`)

        
    }

    

    return(
        <Container>
        <form autoComplete="off" onSubmit={onSubmit} >
            <h2>Products</h2>
                <TextField 
                    label="ProductName"
                      
                    required
                    variant="outlined"
                    color="secondary"
                    type="text"
                    sx={{mb: 3}}
                    fullWidth
                    value={productName}
                    onChange={onNameChangeHandler}
                   
                  
                 />
                 <TextField 
                    label="ProductPrice"
                    value={productPrice}
                    onChange={onPriceChangeHandler}
                    required
                    variant="outlined"
                    color="secondary"
                    type="number"
                
                    fullWidth
                    sx={{mb: 3}}
                 />
                 <Button variant="outlined" color="secondary" type="submit">Add To Basket</Button>
             
        </form>
    
        </Container>
    )
}