import { useEffect } from 'react';
import {useParams} from  'react-router-dom';
import agent from '../Axios/agent';
import { Grid, Typography, Divider, TableContainer, Table, TableBody, TableRow, TableCell, TextField, Button, Container } from '@mui/material';
import iCustomer from '../Models/ICustomer';
import {useState} from 'react'

export default function  CustomerInfo(){

    const {id}=useParams();
    const [customer,setCustomer]=useState<iCustomer|null>();
    useEffect(() => {
        console.log(id)
        if(id!=null){
        agent.Customers.details(parseInt(id))
          .then((data) => setCustomer(data))
          .catch((err) => console.log(err));}
      }, [id]);


      

    return (

        <Container>
        <Grid container spacing={6}>
        <Grid item xs={6}
        >
       <img width={'100%'} src="https://preview.redd.it/ffjmneroeu391.png?width=594&format=png&auto=webp&s=b45e7666cd85b20f59df250ee624cd2021e31d99"></img>
        </Grid>
        <Grid item xs={6}>
           
         <Typography variant="h2">{customer?.name}</Typography>
         <Divider/>
<Typography variant="h4" color="secondary.main">Your Id :{customer?.id}</Typography>
      
        <TableContainer>
             <Table>
             <TableBody>
                 <TableRow>
                    <TableCell>Date Of Birth</TableCell>
                    <TableCell>{customer?.dateOfBirth!=null&&new Date(customer?.dateOfBirth).toDateString()}</TableCell>
                 </TableRow>
                 <TableRow>
                    <TableCell>Date Joined</TableCell>
                    <TableCell>{customer?.dateJoined!=null&&new Date(customer?.dateJoined).toDateString()}</TableCell>
                
                
                 </TableRow>
                
             </TableBody>
             </Table>
        </TableContainer>
        

     
        </Grid>

        </Grid>
        </Container>
    )
}