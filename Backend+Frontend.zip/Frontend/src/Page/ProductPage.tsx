
import { NavLink, useNavigate, useParams } from "react-router-dom";
import agent from "../Axios/agent";
import iCustomer from "../Models/ICustomer";
import {useEffect, useState} from 'react';
import { Remove, Add, Delete, Edit } from "@mui/icons-material";
import { TableContainer, Paper, Table, TableHead, TableRow, TableCell, TableBody, Button, IconButton, Container, Box, TablePagination } from "@mui/material";
import iProduct from "../Models/IProduct";
import { error } from "console";

export default function ProductPage(){
    const {id}=useParams();

    const navigate=useNavigate();
    
    const[product,setProduct]=useState<Array<iProduct>|[]>([]);
  
   async function fetchTheList(id:number){
     await agent.Products.list(id)
      .then((data) =>   

      data!=null&&
      
      setProduct(data))
      .catch((err) => 
      {
        console.log(err);
setProduct([]);
      })
    }
    useEffect(() => {
        console.log(id)
        if(id!=null){

          try{
            fetchTheList(parseInt(id))}
            catch(error){
              console.log(error);
            }
       }
      }, [id,]);


   

    
  function onDeleteButton(productId:number): void {
     
   id!=null&&  agent.Products.delete(productId)
     .then(()=>   fetchTheList(parseInt(id)))
     .catch(error=>console.log(error));


  ;

     
  }

  function onEditButton(id: number): void {
    navigate(`/Edit/${id}`);
  }

    return(
        <Container>
            <Box display="flex" justifyContent={"flex-end"}>
            <Button component={NavLink} to={`/add/${id}`} sx={{m:1}} variant="contained" disableElevation>
  Add Products
</Button></Box>
        <TableContainer   component={Paper}>
        <Table aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell align="center">Id</TableCell>
              <TableCell align="center">ProductName</TableCell>
              <TableCell align="center">ProductPrice</TableCell>
              <TableCell></TableCell>
             
            </TableRow>
          </TableHead>
        
            {
                product.map(p=><TableBody key={p.id}>
                   <TableCell align="center">
                    {p.id}
                   </TableCell>
                   <TableCell align="center">
                    {p.productName}
                   </TableCell>
                   <TableCell align="center">
                    {p.productPrice}
                   </TableCell>
                   <TableCell align="right">

<Button onClick={()=>onDeleteButton(p.id)}>
  <IconButton color="error">
      <Delete/>

  </IconButton>
  </Button>
  <Button onClick={()=>onEditButton(p.id)}>
  <IconButton color="error">
      <Edit/>

  </IconButton>
  </Button>
</TableCell>
                </TableBody>)
            }
             
        
    </Table>
        
      
      </TableContainer>
      <TablePagination
  component="div"
  count={100}
  page={3}
  onPageChange={()=>{}}
  rowsPerPage={2}
  onRowsPerPageChange={()=>{}}
/>
      </Container>
    )
}


