import React from 'react';
import logo from './logo.svg';
import './App.css';

import { Outlet, RouterProvider } from 'react-router-dom';
import router from './Router/route';

import LeftBar from './Components/leftBar';
import { Grid } from '@mui/material';




//Here we are just handling the basic layout
function App() {
  return (
    <div className="App">
      <Grid container spacing={2}>
        <Grid item xs={2}>
        <LeftBar/>
        </Grid>
        <Grid item xs={10} mt={5}>
        <Outlet/>
        </Grid>
      
   
      </Grid>
       
    </div>
  );
}

export default App;
