import { AccountCircle } from "@mui/icons-material";



import {
  AppBar,
  Box,
  Button,
  CssBaseline,
  Divider,
  Drawer,
  Grid,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  MenuItem,
  Select,
  Toolbar,
  makeStyles,

} from "@mui/material";
import { Fragment, useEffect, useState } from "react";
import SelectButton from "./SelectButton";

import agent from "../Axios/agent";
import iCustomer from "../Models/ICustomer";
import { NavLink, useMatch, useNavigate } from "react-router-dom";
import router from "../Router/route";


export default function LeftBar() {

 //We are poputlating the list from our api

 
  const [customer, setCustomer] = useState<iCustomer[] | []>([]);
 
  const [value, setValue] = useState(0);
  const match :any= useMatch('/:base/*'); // 

  console.log(match)

  // Extract the base URL from the path
 
  const navigate=useNavigate();
  useEffect(() => {
    agent.Customers.list()
      .then((data:iCustomer[]) =>{
        setCustomer(data) ;
        setValue(data[0].id);
        navigate(`customer/${data[0].id}`);
      })
      .catch((err) => console.log(err));
    
  }, []);

  console.log(customer);

  function onChangeHandler(e: any): void {
    console.log(e.target.value);
    setValue(e.target.value);
    console.log(match)
  
     
   
     
    

    if(match.pathnameBase=="/customer"){
      
      navigate(`${match.pathnameBase}/${e.target.value}`
      )
    }
  else if(match.pathnameBase=="/products"){

    
    navigate(`${match.pathnameBase}/${e.target.value}`)
  }

    
  }

  return (
    <div   style={{ height: "calc(100vh - 64px)" }}>
      
        <Drawer variant="permanent" anchor="left">
          <List>
            <ListItem>
              <SelectButton
                onChange={onChangeHandler}
                Collection={customer}
                selectValue={value}
              />
            </ListItem>

           <Divider/>
            <ListItem>
              <Button
              
                component={NavLink}
                to={`customer/${value}`}
        
                sx={{ width: "200px"
              
              }}
                variant="contained"
                
               
              >
                Customer Info
              </Button>
            </ListItem>
            <ListItem>
              <Button
           
                component={NavLink}
                to={`products/${value}`}
                sx={{ width: "200px" }}
                variant="contained"
            
              >
                Product Info
              </Button>
            </ListItem>
          </List>
        </Drawer>
      </div>
      
  
  );
}
