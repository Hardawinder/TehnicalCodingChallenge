import { Select, MenuItem } from "@mui/material"
import { Fragment } from "react"
import iCustomer from "../Models/ICustomer"


export default function SelectButton ({selectValue,Collection,onChange}:{selectValue:number,Collection:Array<iCustomer>|[],onChange:(e:any)=>void}){
    const arr=[{value:1,color:"black"},{value:2,color:"blue"}]


 
    return (
        <Fragment>
            <Select
         value={selectValue}

         onChange={onChange}
         sx={{ width: "200px" }}
         
           
      >

       
     
          {

Collection!=null&&Collection.map(Customer=><MenuItem key={Customer.id} value={Customer.id}>
 {Customer.name} 
</MenuItem>)

          }
        

      
      </Select>
        </Fragment>
    )
}