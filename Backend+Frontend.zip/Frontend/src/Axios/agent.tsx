import axios, {AxiosError, AxiosRequestConfig, AxiosResponse } from "axios";
import iPostProduct from "../Models/IPostProduct";


axios.defaults.baseURL='https://localhost:7284/api';
axios.defaults.withCredentials=true;




const responseBody=(response:AxiosResponse)=>
    response.data;
    axios.interceptors.response.use(async response=>{
 
        
        return response;
    }
    ,(error:AxiosError)=>{
    
        const {data,status}=error.response as AxiosResponse ;
      
      
        switch(status){
            case 400:
                console.log("yes 400")
               

                if(data.errors){
                    const modelS:string[]=[];
                    for(var problem in data.errors){
                       
                        modelS.push(data.errors[problem]);
                    }
                    console.log(modelS)
                    throw modelS.flat();
                }
               
                break;
                case 500:
                    console.log("first")
         
                    break;
                case 404|401:
                console.log("yes")
               
                break;
                default:
                console.log("this is the default error");
                break;
        }

       
    }
    )
const requests={
    get:(url:string)=>axios.get(url).then(responseBody),
    post:(url:string,body:{})=>axios.post(url,body).then(responseBody),
    put:(url:string,body:{})=>axios.put(url,body).then(responseBody),
    delete:(url:string)=>axios.delete(url).then(responseBody),
}    


const Customers={
    list:()=>requests.get(`Customers`),
    details:(id:number)=>requests.get(`Customers/${id}`)
}

const Products={

    list:(custId:number)=>requests.get(`Product?customerId=${custId}`),
    add:(custId:number,body:iPostProduct)=>requests.post(`Product`,body),
    getByProId:(productId:number)=>requests.get(`Product/GetByProductId?ProductId=${productId}`),
    delete:(productId:number)=>requests.delete(`Product?productId=${productId}`),
    put:(productId:number,body:iPostProduct)=>requests.put(`Product/${productId}`,body)
}




const agent={
    Customers,
    Products
}


export default agent;