using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Backend.Entities
{
    public class RequestProduct
    {
        public int Id { get; set; }    
        public string ProductName { get; set;}

        public double ProductPrice { get; set; }

        public Customer Customer{ get; set; }
        public int CustomerId { get; set; }
    }
}