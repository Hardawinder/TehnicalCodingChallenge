using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Backend.Entities
{
    public class Customer
    {
        public int Id { get; set; }

        public string Name { get; set; }
        
        public DateTime DateOfBirth { get; set; }


        public DateTime DateJoined { get; set; } = DateTime.Now;

        public List<RequestProduct>? RequestProducts{ get; set; }=new ();
    }
}