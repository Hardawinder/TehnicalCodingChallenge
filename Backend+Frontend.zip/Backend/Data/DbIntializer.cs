﻿using Backend.Entities;

namespace Backend.Data
{
    public static class DbIntializer
    {
        public static async void Intilize(ApplicationContext context)
        {
            if (context.Customer.Any())
            {
                return;
            }

            var customers = new List<Customer> {new Customer
            {
            
                Name = "Abby Johnson",
                DateOfBirth = new DateTime(1990, 5, 15),
                DateJoined = DateTime.Now.AddMonths(-6),
                RequestProducts = new List<RequestProduct>
                    {
                        new RequestProduct
                        {
                            
                            ProductName = "Widget A",
                            ProductPrice = 20.0
                        },
                        new RequestProduct
                        {

                            ProductName = "Gadget X",
                            ProductPrice = 50.0
                        }
                    }
            },
                    new Customer
                        {
                            Name = "Sam Smith",
                        DateOfBirth = new DateTime(1985, 10, 2),
                        DateJoined = DateTime.Now.AddMonths(-12),
                        RequestProducts = new List<RequestProduct>
                        {
                        new RequestProduct
                        {
                           
                            ProductName = "Widget B",
                            ProductPrice = 25.0
                        },
                        new RequestProduct
                        {
                           
                            ProductName = "Accessory Y",
                            ProductPrice = 10.0
                        }
                        }
                    },
                    // Add more customers here
                    new Customer
                    {
                        Name = "Emily Anderson",
                        DateOfBirth = new DateTime(1988, 3, 20),
                        DateJoined = DateTime.Now.AddMonths(-8),
                        RequestProducts = new List<RequestProduct>
                        {
                            new RequestProduct
                            {
    
                                ProductName = "Tool Kit Z",
                                ProductPrice = 30.0
                            },
                            new RequestProduct
                            {
                       
                                ProductName = "Gizmo Q",
                                ProductPrice = 15.0
                            }
                        }
                    }
            };
                        
            await context.Customer.AddRangeAsync(
    customers

    );
          await  context.SaveChangesAsync();


        }
    }
}
