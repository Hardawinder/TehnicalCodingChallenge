﻿using Backend.Entities;
using Backend.IGenericRepository;

namespace Backend.IRepository
{
    public interface IProductRepository:IGenericRepository<RequestProduct>
    {

        public Task<List<RequestProduct>> GetAll(int customerId);

        public Task<int> GetCount(int customerId);
    }
}
