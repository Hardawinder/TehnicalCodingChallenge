﻿using Backend.Entities;
using Backend.IGenericRepository;
using Backend.Repository;

namespace Backend.IRepository
{
    public interface ICustomerRepository:IGenericRepository<Customer>
    {
    }
}
