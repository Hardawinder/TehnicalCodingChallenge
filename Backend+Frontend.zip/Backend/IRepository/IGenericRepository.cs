﻿namespace Backend.IGenericRepository
{
    public interface IGenericRepository <T> where T : class
    {

        public Task<List<T>> GetAllAsync();

        public Task<bool> ExistsAsync(int id);

        public Task DeleteAsync(int id);

        public Task AddAsync(T entity);
        public Task UpdateAsync(T entity);

        public Task<T> GetIdByAsync(int? id);


        public Task AddRangeAsync(List<T> list);

        

            /*
               public Task<bool> Exists(int id);
        public Task<T> GetIdByAsync(int id);
        public Task Update(T entity);

        public Task Delete(int id);
            */
    }
}
