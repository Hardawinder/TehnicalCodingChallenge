﻿namespace Backend.ModelVM
{
    public class CustomerVMR
    {
        public string Name { get; set; }

        public DateTime DateOfBirth { get; set; }

        public int id { get; set; }
        public DateTime DateJoined { get; set; }

        public int TotalProductBought { get; set; }
    }
}
