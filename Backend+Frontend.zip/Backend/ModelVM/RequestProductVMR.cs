﻿using Backend.Entities;

namespace Backend.ModelVM
{
    public class RequestProductVMR
    {
       
        public string ProductName { get; set; }

        public double ProductPrice { get; set; }

   
        public int CustomerId { get; set; }
         public int Id { get; set; }
    }
}
