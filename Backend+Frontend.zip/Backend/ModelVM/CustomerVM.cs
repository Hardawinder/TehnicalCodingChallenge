﻿using Backend.Entities;

namespace Backend.ModelVM
{
    public class CustomerVM
    {

    

        public string Name { get; set; }

        public DateTime DateOfBirth { get; set; }


     
        
    }
}
