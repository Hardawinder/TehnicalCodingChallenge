﻿namespace Backend.ModelVM
{
    public class RequestProductVMPost
    {
        public string ProductName { get; set; }

        public double ProductPrice { get; set; }
    }
}
