﻿using Backend.Entities;

namespace Backend.ModelVM
{
    public class RequestProductVM
    {
       
        public string ProductName { get; set; }

        public double ProductPrice { get; set; }

   
        public int CustomerId { get; set; }
    }
}
