﻿using AutoMapper;
using Backend.Entities;
using Backend.ModelVM;

namespace Backend.MapperConfig
{
    public class Mapper:Profile
    {

        public Mapper() {

            CreateMap<Customer, CustomerVM>().ReverseMap();
            CreateMap<Customer, CustomerVMR>().ReverseMap();
            CreateMap<Customer, RequestProductVM>().ReverseMap();
            CreateMap<RequestProduct, RequestProductVM>().ReverseMap();
            CreateMap<RequestProduct, RequestProductVMR>().ReverseMap();
        } 
    }
}
