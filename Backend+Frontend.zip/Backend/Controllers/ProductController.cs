﻿using AutoMapper;
using Backend.Entities;
using Backend.IRepository;
using Backend.ModelVM;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.EntityFrameworkCore;

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        public readonly IProductRepository productRepository;

        public readonly ICustomerRepository customerRepository;

        public readonly IMapper mapper;
        public ProductController(IProductRepository productRepository, ICustomerRepository customerRepository, IMapper mapper)
        {
            this.mapper = mapper;
            this.customerRepository = customerRepository;
            this.productRepository = productRepository;
        }






        [HttpGet]
        public async Task<ActionResult<List<RequestProductVMR>>> GetAll(int customerId)
        {

            var ProductList = await productRepository.GetAll(customerId);



            if (!ProductList.Any())
            {
                return BadRequest();
            }

            return mapper.Map<List<RequestProductVMR>>(ProductList);

            //  return ProductList;

        }


        [HttpGet("GetByProductId")]
        public async Task<ActionResult<RequestProductVMR>> GetItAll2(int ProductId)
        {

            var ProductList = await productRepository.GetIdByAsync(ProductId);
            if (ProductList == null)
            {
                return BadRequest();
            }

            return mapper.Map<RequestProductVMR>(ProductList);

            //  return ProductList;

        }
        [HttpDelete]
        public async Task<ActionResult<RequestProductVM>> DeleteTheProduct(int productId)
        {
            var Product = await productRepository.GetIdByAsync(productId);


            if (Product == null)
            {
                return BadRequest();
            }

            await productRepository.DeleteAsync(productId);
            return mapper.Map<RequestProductVM>(Product);

        }

        [HttpPost]

        public async Task<ActionResult<RequestProductVM>> addTheProduct(RequestProductVM requestProductVM)
        {

            var requestProduct = mapper.Map<RequestProduct>(requestProductVM);

            Console.WriteLine(requestProduct.CustomerId);
            var customer = await customerRepository.GetIdByAsync(requestProduct.CustomerId);

            if (customer == null) { return BadRequest(); }

            try
            {
                await productRepository.AddAsync(requestProduct);

                return requestProductVM;
            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }





        }


        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<ActionResult<RequestProductVM>> PutProduct(int id, RequestProductVM requestProductVM)
        {

            var product = await productRepository.GetIdByAsync(id);
           




            try
            {

                product.ProductPrice = requestProductVM.ProductPrice;
                product.ProductName = requestProductVM.ProductName;

                await productRepository.UpdateAsync(product);

                return requestProductVM;
            }
            catch (DbUpdateConcurrencyException ex)
            {
                throw new Exception(ex.Message);
            }

            return NoContent();
        }
    }
}
