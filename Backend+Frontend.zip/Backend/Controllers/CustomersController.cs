﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Backend.Data;
using Backend.Entities;
using Microsoft.AspNetCore.WebUtilities;
using AutoMapper;
using Backend.ModelVM;
using Backend.IRepository;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
       
        private readonly IMapper mapper;
        private ICustomerRepository customerRepository;
        private IProductRepository productRepository;

        public CustomersController(IMapper mapper,ICustomerRepository customerRepository, IProductRepository productRepository)
        {
          
            this.mapper = mapper;
            this.customerRepository = customerRepository;
            this.productRepository = productRepository;
        }

        // GET: api/Customers
        [HttpGet]
        public async Task<ActionResult<List<CustomerVMR>>> GetCustomer()
        {
          

            var customers = await customerRepository.GetAllAsync();

            if (customers == null)
            {
                return NotFound(); 
            }


            var customerVMRList = mapper.Map<List<CustomerVMR>>(customers);

            

                
                ;

            return customerVMRList;
        }

        // GET: api/Customers/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CustomerVMR>> GetCustomer(int id)
        {
       
            var customer = await customerRepository.GetIdByAsync(id);
            

            if (customer == null)
            {
                return NotFound();
            }

            var customerVMR=mapper.Map<CustomerVMR>(customer);

            customerVMR.TotalProductBought =await productRepository.GetCount(id);

            return customerVMR;
        }

        // PUT: api/Customers/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCustomer(int id, CustomerVM customerVM)
        {

            var customer =await customerRepository.GetIdByAsync(id);
            if(customer == null)
            {
                return BadRequest();
            }
           
            

            

            try
            {

                customer.Name= customerVM.Name;
                customer.DateOfBirth = customerVM.DateOfBirth;

               await customerRepository.UpdateAsync(customer);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CustomerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Customers
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Customer>> PostCustomer(CustomerVM customerVM)
        {


            try
            {

                if (ModelState.IsValid)
                {
                    var customer = mapper.Map<Customer>(customerVM);

                    await customerRepository.AddAsync(customer);



                    return CreatedAtAction("GetCustomer", new { id = customer.Id }, customerVM);

                }

                else
                {
                    return BadRequest();
                }

            }
            catch (Exception ex)
            {
                 throw new Exception(ex.Message);
            }
         
        }

        // DELETE: api/Customers/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCustomer(int id)
        {
            
            var customer = await customerRepository.GetIdByAsync(id);
            if (customer == null)
            {
                return NotFound();
            }

           

            await customerRepository.DeleteAsync(id);

            return NoContent();
        }

        private bool CustomerExists(int id)
        {
            return customerRepository.GetIdByAsync(id)!=null;
        }
    }
}
