﻿using Backend.IGenericRepository;
using Backend.Data;
using Microsoft.EntityFrameworkCore;

namespace Backend.Repository
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        public readonly ApplicationContext _context;
        public GenericRepository(ApplicationContext context)
        {
            _context = context;
        }

        public async Task AddAsync(T entity)
        {
            await _context.Set<T>().AddAsync(entity);
            
            await _context.SaveChangesAsync();

        //    throw new NotImplementedException();
        }

        public async Task AddRangeAsync(List<T> list)
        {

           await _context.AddRangeAsync(list);  
            await _context.SaveChangesAsync();
            
        }

        public async Task DeleteAsync(int id)
        {
            
            var entity=await GetIdByAsync(id);
            _context.Set<T>().Remove(entity);
            await _context.SaveChangesAsync();

           
        }

        public async Task<bool> ExistsAsync(int id)
        {
            var entity=await GetIdByAsync(id);
            return entity!=null; 
        }

        public async Task<List<T>> GetAllAsync()
        {
            return await _context.Set<T>().ToListAsync();
        }

        public async Task<T> GetIdByAsync(int? id)
        {


            return await _context.Set<T>().FindAsync(id);
        }

        public async Task UpdateAsync( T entity)
        {

            _context.Set<T>().Update(entity);
            await _context.SaveChangesAsync();
            
        }

        

       
    }
}
