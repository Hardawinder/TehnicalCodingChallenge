﻿using Backend.Data;
using Backend.Entities;
using Backend.IGenericRepository;
using Backend.IRepository;

namespace Backend.Repository
{
    public class CustomerRepository : GenericRepository<Customer>, ICustomerRepository
    {
        public CustomerRepository(ApplicationContext context) : base(context)
        {
        }
    }
}
