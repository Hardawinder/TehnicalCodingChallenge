﻿using Backend.Data;
using Backend.Entities;
using Backend.IRepository;
using Microsoft.EntityFrameworkCore;

namespace Backend.Repository
{
    public class ProductRepository : GenericRepository<RequestProduct>, IProductRepository
    {

        public readonly ApplicationContext _context;
        public ProductRepository(ApplicationContext context) : base(context)
        {
            this._context = context;
        }

        public async Task<List<RequestProduct>> GetAll(int customerId)
        {
           var productList= await _context.Products.Where(p=>p.CustomerId== customerId).ToListAsync();

            if(productList.Any())
            {
                return productList;
            }

            return null;

           
        }

        public async Task<int> GetCount(int customerId)
        {
            return await _context.Products.Where(p=>p.CustomerId== customerId).CountAsync();
        }
    }
}
