﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Backend.Migrations
{
    /// <inheritdoc />
    public partial class changes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_RequestProduct_Customer_CustomerId",
                table: "RequestProduct");

            migrationBuilder.DropPrimaryKey(
                name: "PK_RequestProduct",
                table: "RequestProduct");

            migrationBuilder.RenameTable(
                name: "RequestProduct",
                newName: "Products");

            migrationBuilder.RenameIndex(
                name: "IX_RequestProduct_CustomerId",
                table: "Products",
                newName: "IX_Products_CustomerId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Products",
                table: "Products",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Products_Customer_CustomerId",
                table: "Products",
                column: "CustomerId",
                principalTable: "Customer",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Products_Customer_CustomerId",
                table: "Products");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Products",
                table: "Products");

            migrationBuilder.RenameTable(
                name: "Products",
                newName: "RequestProduct");

            migrationBuilder.RenameIndex(
                name: "IX_Products_CustomerId",
                table: "RequestProduct",
                newName: "IX_RequestProduct_CustomerId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_RequestProduct",
                table: "RequestProduct",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_RequestProduct_Customer_CustomerId",
                table: "RequestProduct",
                column: "CustomerId",
                principalTable: "Customer",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
